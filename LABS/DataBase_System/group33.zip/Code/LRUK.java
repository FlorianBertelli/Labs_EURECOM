/* File LRUK.java */

package bufmgr;

import diskmgr.*;
import global.*;
import java.util.ArrayList;

  /**
   * class LRU is a subclass of class Replacer using LRUK
   * algorithm for page replacement
   */
public class LRUK extends  Replacer {


  private int k;

  /**
   * private field
   * An array to hold number of frames in the buffer pool
   */

    private int  frames[];
 
  /**
   * private field
   * number of frames used
   */   
  private int  nframes;

  /**
   * private field containing the list of the page accessed 
   */   
 private ArrayList<Integer> list = new ArrayList<Integer>();

  
//This add the page used at the end of the list in order to compute the backward distance

  private void update(int frameNo)
  {
    list.add(frameNo);

     int index;
     for ( index=0; index < nframes; ++index )
        if ( frames[index] == frameNo )
            break;

	
  }

  /**
   * Calling super class the same method
   * Initializing the frames[] with number of buffer allocated
   * by buffer manager
   * set number of frame used to zero
   *
   * @param	mgr	a BufMgr object
   * @see	BufMgr
   * @see	Replacer
   */
    public void setBufferManager( BufMgr mgr )
     {
        super.setBufferManager(mgr);
	frames = new int [ mgr.getNumBuffers() ];
	nframes = 0;
     }

/* public methods */

  /**
   * Class constructor
   * Initializing frames[] pinter = null.
   */
    public LRUK(BufMgr mgrArg, int K)
    {
      super(mgrArg);
      frames = null;
      this.k = K;
    }
  
  /**
   * calll super class the same method
   * pin the page in the given frame number 
   * move the page to the end of list  
   *
   * @param	 frameNo	 the frame number to pin
   * @exception  InvalidFrameNumberException
   */
 public void pin(int frameNo) throws InvalidFrameNumberException
 {
    super.pin(frameNo);
    state_bit[frameNo].state = Pinned;

  //  update(frameNo);
    
 }

/*
	Return the last time we used this page
*/
public int last(int pageNumber) {
	int size = list.size() - 1;
	for (int i = size; i >= 0; i--) {
		if(list.get(i) == pageNumber)
			return size - i;
	}
	return -1; 
}

/*
	
*/

public int HIST( int k_times, int pageNumber) {
	int size = list.size() - 1;
	int count = 0;
	for (int i = size; i >= 0; i--) {
		if(list.get(i) == pageNumber)
			count++;
		if(count == k_times)
			return size - i;
	}
	return -1; 
}



/*
* Function that calculate the backwardDistance for the page number mentionned in argument
*/

public int backwardDistance(int pageNumber) {
	int x = -1;	// case if never used 
	int size = list.size() - 1; 
	int count = 0;
	// iterating the list by the end in order to determine the last k iterations of pageNumber 
	for (int i = size; i >= 0; i--) { 
		if(list.get(i) == pageNumber)
			count++; // each time we find the page we count it in order to determine the number of apparitions
		
		if(count == k){ // we have found the last K iterations so this is our backward distance
			x = size - i;
}
	}
	if(x < 0)
		return -1; //case infinity
	return x;
}


  /**
   * Finding a free frame in the buffer pool
   * or choosing a page to replace using LRUK policy
   *
   * @return 	return the frame number
   *		return -1 if failed
   */

 public int pick_victim() throws BufferPoolExceededException
 {
   	int numBuffers = mgr.getNumBuffers();	
	int frame;
	int B;
	   
	   //if the buffer pool is not full
	    if ( nframes < numBuffers ) {
		frame = nframes++;
		frames[frame] = frame;
		state_bit[frame].state = Pinned;
		(mgr.frameTable())[frame].pin();
		return frame;
	    } 
	// we compute all the backwardDistance value for the different pages and we find the maximum,it is the candidate for eviction
	int maxDistanceIndex = 0;
	int maxDistance = 0;
	for (int i = 0; i < numBuffers; i++) {
		frame = frames[i];
		
		B = backwardDistance(frame); //if we have a never used page we choose it
		
		if(B < 0 && state_bit[frame].state != Pinned)	{		
			 state_bit[frame].state = Pinned;			
			(mgr.frameTable())[frame].pin();
			return frame;
		}

		if(maxDistance < B && state_bit[frame].state != Pinned ) { //we find the maximun value and its corresponding value by iterating the list
			 state_bit[frame].state = Pinned;			
			(mgr.frameTable())[frame].pin();
			maxDistance = B;
			maxDistanceIndex = i;
		}
	}

   	return frames[maxDistanceIndex];
	 
	
 }




public int[] getFrames()
{
	return frames;
}
  /**
   * get the page replacement policy name
   *
   * @return	return the name of replacement policy used
   */  
    public String name() { return "LRUK"; }
 
  /**
   * print out the information of frame usage
   */  
 public void info()
 {
    super.info();

    System.out.print( "LRUK REPLACEMENT");
    
    for (int i = 0; i < nframes; i++) {
        if (i % 5 == 0)
	System.out.println( );
	System.out.print( "\t" + frames[i]);
        
    }
    System.out.println();
 }
  
}



